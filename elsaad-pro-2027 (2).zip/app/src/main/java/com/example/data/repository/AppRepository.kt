package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.remote.FileDownloadManager
import com.example.data.remote.FirebaseRealtimeService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val firebase = FirebaseRealtimeService()
    val downloadManager = FileDownloadManager(context)
    private val prefs = context.getSharedPreferences("elsaad_pro_prefs", Context.MODE_PRIVATE)

    val allCourses: Flow<List<CourseEntity>> = db.courseDao().getAllCourses()
    val allAuditLogs: Flow<List<AuditLog>> = db.auditDao().getAuditLogs()
    val downloadItems: StateFlow<List<DownloadItem>> = downloadManager.downloadItems

    fun getSectionsForCourse(courseId: String): Flow<List<SectionEntity>> =
        db.sectionDao().getSectionsForCourse(courseId)

    fun getUnlockedCourses(username: String): Flow<List<CourseEntity>> =
        db.accessDao().getUnlockedCourses(username)

    fun getUnlockedCourseIds(username: String): Flow<List<String>> =
        db.accessDao().getUnlockedCourseIds(username)

    fun getFavorites(username: String): Flow<List<UserFavorite>> =
        db.favoriteDao().getFavorites(username)

    fun getCourseProgress(username: String, courseId: String): Flow<List<LessonProgress>> =
        db.progressDao().getProgressForCourse(username, courseId)

    fun getLastWatched(username: String): Flow<LessonProgress?> =
        db.progressDao().getLastWatchedLesson(username)

    fun getAllUsers(): Flow<List<UserEntity>> = db.userDao().getAllUsers()
    fun getAllCodes(): Flow<List<ActivationCodeEntity>> = db.codeDao().getAllCodes()

    // Preferences
    fun getSavedUser(): String? = prefs.getString("current_user", null)
    fun getSavedRole(): String = prefs.getString("current_role", "none") ?: "none"
    fun getTheme(): String = prefs.getString("app_theme", "default") ?: "default"
    fun isDarkMode(): Boolean = prefs.getBoolean("is_dark_mode", false)
    fun getLangMain(): String = prefs.getString("lang_main", "ar") ?: "ar"
    fun getLangStyle(): String = prefs.getString("lang_style", "amiyya") ?: "amiyya"

    fun saveUserSession(username: String, role: String) {
        prefs.edit().putString("current_user", username).putString("current_role", role).apply()
    }

    fun clearSession() {
        prefs.edit().remove("current_user").remove("current_role").apply()
    }

    fun saveTheme(theme: String) {
        prefs.edit().putString("app_theme", theme).apply()
    }

    fun saveDarkMode(isDark: Boolean) {
        prefs.edit().putBoolean("is_dark_mode", isDark).apply()
    }

    fun saveLangMain(main: String) {
        prefs.edit().putString("lang_main", main).apply()
    }

    fun saveLangStyle(style: String) {
        prefs.edit().putString("lang_style", style).apply()
    }

    // Sync from Firebase
    suspend fun syncPathsAndSections() = withContext(Dispatchers.IO) {
        val remotePaths = firebase.fetchPaths()
        if (remotePaths.isNotEmpty()) {
            db.courseDao().insertCourses(remotePaths.values.toList())
            for ((pathId, _) in remotePaths) {
                val sections = firebase.fetchSectionsForPath(pathId)
                if (sections.isNotEmpty()) {
                    db.sectionDao().insertSections(sections)
                }
            }
        }
    }

    suspend fun syncUserAccess(username: String) = withContext(Dispatchers.IO) {
        val openedPaths = firebase.getUserOpenedPaths(username)
        for (pathId in openedPaths) {
            db.accessDao().grantAccess(UserCourseAccess(username, pathId))
        }
    }

    // Auth & Users
    suspend fun login(username: String, pass: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        if (username.trim() == "MohamedX" && pass.trim() == "20092009") {
            saveUserSession("MohamedX", "admin")
            db.userDao().insertUser(UserEntity(username = "MohamedX", role = "admin", xp = 9999))
            logAudit("MohamedX", "تسجيل دخول كمدير", "لوحة الإدارة")
            return@withContext Pair(true, "admin")
        }

        val remoteUser = firebase.getUser(username.trim())
        if (remoteUser != null && remoteUser.password == pass.trim()) {
            if (remoteUser.isBlocked) {
                return@withContext Pair(false, "الحساب محظور حالياً، تواصل مع الإدارة")
            }
            saveUserSession(username.trim(), "student")
            db.userDao().insertUser(remoteUser)
            syncUserAccess(username.trim())
            return@withContext Pair(true, "student")
        }

        // Check local DB if offline
        val localUser = db.userDao().getUserByUsername(username.trim())
        if (localUser != null && localUser.password == pass.trim()) {
            if (localUser.isBlocked) return@withContext Pair(false, "الحساب محظور")
            saveUserSession(username.trim(), localUser.role)
            return@withContext Pair(true, localUser.role)
        }

        return@withContext Pair(false, "اسم المستخدم أو كلمة السر غير صحيحة")
    }

    suspend fun register(username: String, pass: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val existing = firebase.getUser(username.trim())
        if (existing != null) {
            return@withContext Pair(false, "هذا الاسم مسجل بالفعل، اختر اسماً آخر")
        }
        val success = firebase.registerUser(username.trim(), pass.trim())
        if (success) {
            val user = UserEntity(username = username.trim(), password = pass.trim(), role = "student", xp = 50)
            db.userDao().insertUser(user)
            return@withContext Pair(true, "تم إنشاء الحساب بنجاح!")
        }
        return@withContext Pair(false, "فشل إنشاء الحساب، تحقق من اتصالك")
    }

    // Code Activation
    suspend fun activateCode(code: String, username: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val cleanCode = code.trim()
        if (cleanCode.length != 10) {
            return@withContext Pair(false, "الكود يجب أن يتكون من 10 أرقام بالضبط")
        }
        val result = firebase.findAndRedeemCode(cleanCode, username)
        if (result.first) {
            syncPathsAndSections()
            syncUserAccess(username)
            db.userDao().addXp(username, 100)
            logAudit(username, "تفعيل كود", "كود $cleanCode - ${result.second}")
        }
        return@withContext result
    }

    // Admin Course Management
    suspend fun createCourse(name: String, prefix: String, suffix: String): Boolean = withContext(Dispatchers.IO) {
        val courseId = "p_" + System.currentTimeMillis()
        val success = firebase.saveCourse(courseId, name, prefix, suffix)
        if (success) {
            db.courseDao().insertCourse(CourseEntity(id = courseId, name = name, prefix = prefix, suffix = suffix))
            logAudit("Admin", "إضافة كورس جديد", name)
        }
        return@withContext success
    }

    suspend fun updateCourse(courseId: String, name: String, prefix: String, suffix: String): Boolean = withContext(Dispatchers.IO) {
        val success = firebase.saveCourse(courseId, name, prefix, suffix)
        if (success) {
            db.courseDao().insertCourse(CourseEntity(id = courseId, name = name, prefix = prefix, suffix = suffix))
            logAudit("Admin", "تعديل كورس", name)
        }
        return@withContext success
    }

    suspend fun deleteCourse(courseId: String, courseName: String): Boolean = withContext(Dispatchers.IO) {
        val success = firebase.deleteCourse(courseId)
        db.courseDao().deleteCourseById(courseId)
        db.sectionDao().deleteSectionsForCourse(courseId)
        logAudit("Admin", "حذف كورس", courseName)
        return@withContext success
    }

    // Admin Content Management
    suspend fun addSection(courseId: String, name: String, link: String, tag: String, type: String): Boolean = withContext(Dispatchers.IO) {
        val sectionId = "s_" + System.currentTimeMillis()
        val success = firebase.addSection(courseId, sectionId, name, link, tag, type)
        if (success) {
            db.sectionDao().insertSection(
                SectionEntity(id = sectionId, courseId = courseId, name = name, link = link, tag = tag, type = type)
            )
            logAudit("Admin", "إضافة محتوى $type", name)
        }
        return@withContext success
    }

    suspend fun deleteSection(courseId: String, sectionId: String, sectionName: String): Boolean = withContext(Dispatchers.IO) {
        val success = firebase.deleteSection(courseId, sectionId)
        db.sectionDao().deleteSectionById(sectionId)
        logAudit("Admin", "حذف محتوى", sectionName)
        return@withContext success
    }

    // Admin Code Generation
    suspend fun generateAndSaveCodes(courseId: String, count: Int, owner: String): List<String> = withContext(Dispatchers.IO) {
        val course = db.courseDao().getCourseById(courseId) ?: return@withContext emptyList()
        val prefix = course.prefix
        val suffix = course.suffix
        val fixedLen = prefix.length + suffix.length
        val randomLen = (10 - fixedLen).coerceAtLeast(1)

        val codes = mutableListOf<String>()
        val codeEntities = mutableListOf<ActivationCodeEntity>()
        val random = java.util.Random()

        for (i in 0 until count) {
            val sb = StringBuilder(prefix)
            for (j in 0 until randomLen) {
                sb.append(random.nextInt(10))
            }
            sb.append(suffix)
            val generated = sb.toString()
            if (generated.length == 10) {
                codes.add(generated)
                codeEntities.add(
                    ActivationCodeEntity(
                        code = generated,
                        courseId = courseId,
                        owner = owner
                    )
                )
            }
        }

        firebase.batchSaveCodes(courseId, codes, owner)
        db.codeDao().insertCodes(codeEntities)
        logAudit("Admin", "توليد أكواد ($count كود)", "كورس ${course.name}")
        return@withContext codes
    }

    // Favorites & Progress
    suspend fun toggleFavorite(username: String, itemId: String, itemType: String, title: String, subtitle: String = "", link: String = "") = withContext(Dispatchers.IO) {
        val isFav = db.favoriteDao().isFavorite(username, itemId)
        if (isFav) {
            db.favoriteDao().removeFavorite(username, itemId)
        } else {
            db.favoriteDao().addFavorite(
                UserFavorite(username = username, itemId = itemId, itemType = itemType, title = title, subtitle = subtitle, link = link)
            )
        }
    }

    suspend fun toggleLessonCompleted(username: String, courseId: String, lessonId: String, completed: Boolean) = withContext(Dispatchers.IO) {
        db.progressDao().saveProgress(
            LessonProgress(username = username, courseId = courseId, lessonId = lessonId, isCompleted = completed, lastWatchedAt = System.currentTimeMillis())
        )
        if (completed) {
            db.userDao().addXp(username, 25)
        }
    }

    suspend fun updateLastWatched(username: String, courseId: String, lessonId: String) = withContext(Dispatchers.IO) {
        val existing = db.progressDao().getProgressForCourse(username, courseId).firstOrNull()?.find { it.lessonId == lessonId }
        val completed = existing?.isCompleted ?: false
        db.progressDao().saveProgress(
            LessonProgress(username = username, courseId = courseId, lessonId = lessonId, isCompleted = completed, lastWatchedAt = System.currentTimeMillis())
        )
    }

    suspend fun logAudit(adminUser: String, action: String, target: String) = withContext(Dispatchers.IO) {
        db.auditDao().insertLog(AuditLog(adminUser = adminUser, action = action, target = target))
    }
}
