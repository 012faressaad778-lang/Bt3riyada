package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "courses")
data class CourseEntity(
    @PrimaryKey val id: String,
    val name: String,
    val prefix: String = "",
    val suffix: String = "",
    val description: String = "",
    val category: String = "رياضيات",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sections")
data class SectionEntity(
    @PrimaryKey val id: String,
    val courseId: String,
    val name: String,
    val link: String,
    val tag: String = "",
    val type: String = "video", // "video" or "pdf"
    val orderIndex: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "activation_codes")
data class ActivationCodeEntity(
    @PrimaryKey val code: String,
    val courseId: String,
    val used: Boolean = false,
    val usedBy: String? = null,
    val usedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val owner: String = "ELSAAD PRO"
)

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val username: String,
    val password: String = "",
    val role: String = "student", // "student" or "admin"
    val xp: Int = 50,
    val streakDays: Int = 1,
    val isBlocked: Boolean = false,
    val lastActiveAt: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_courses", primaryKeys = ["username", "courseId"])
data class UserCourseAccess(
    val username: String,
    val courseId: String,
    val unlockedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "lesson_progress", primaryKeys = ["username", "lessonId"])
data class LessonProgress(
    val username: String,
    val courseId: String,
    val lessonId: String,
    val isCompleted: Boolean = false,
    val lastWatchedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_favorites", primaryKeys = ["username", "itemId", "itemType"])
data class UserFavorite(
    val username: String,
    val itemId: String,
    val itemType: String, // "course" or "lesson"
    val title: String = "",
    val subtitle: String = "",
    val link: String = "",
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val adminUser: String,
    val action: String,
    val target: String
)
