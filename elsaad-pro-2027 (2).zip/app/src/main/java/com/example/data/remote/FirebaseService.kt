package com.example.data.remote

import android.util.Log
import com.example.data.model.ActivationCodeEntity
import com.example.data.model.CourseEntity
import com.example.data.model.SectionEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class FirebaseRealtimeService {
    private val baseUrl = "https://creativity-mr-mohamed-saad-default-rtdb.firebaseio.com"
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchPaths(): Map<String, CourseEntity> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$baseUrl/paths.json")
                .get()
                .build()
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (response.isSuccessful && !body.isNullOrEmpty() && body != "null") {
                val json = JSONObject(body)
                val map = mutableMapOf<String, CourseEntity>()
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val obj = json.getJSONObject(key)
                    val name = obj.optString("name", "كورس جديد")
                    val prefix = obj.optString("prefix", "")
                    val suffix = obj.optString("suffix", "")
                    val createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    map[key] = CourseEntity(
                        id = key,
                        name = name,
                        prefix = prefix,
                        suffix = suffix,
                        createdAt = createdAt
                    )
                }
                return@withContext map
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Error fetching paths: ${e.message}")
        }
        emptyMap()
    }

    suspend fun fetchSectionsForPath(pathId: String): List<SectionEntity> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$baseUrl/paths/$pathId/sections.json")
                .get()
                .build()
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (response.isSuccessful && !body.isNullOrEmpty() && body != "null") {
                val json = JSONObject(body)
                val list = mutableListOf<SectionEntity>()
                val keys = json.keys()
                var index = 0
                while (keys.hasNext()) {
                    val key = keys.next()
                    val obj = json.getJSONObject(key)
                    val name = obj.optString("name", "")
                    val link = obj.optString("link", "")
                    val tag = obj.optString("tag", "")
                    val type = obj.optString("type", "video")
                    val createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    list.add(
                        SectionEntity(
                            id = key,
                            courseId = pathId,
                            name = name,
                            link = link,
                            tag = tag,
                            type = type,
                            orderIndex = index++,
                            createdAt = createdAt
                        )
                    )
                }
                return@withContext list
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Error fetching sections for $pathId: ${e.message}")
        }
        emptyList()
    }

    suspend fun getUser(username: String): UserEntity? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$baseUrl/users/$username.json")
                .get()
                .build()
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (response.isSuccessful && !body.isNullOrEmpty() && body != "null") {
                val obj = JSONObject(body)
                val pass = obj.optString("pass", "")
                val xp = obj.optInt("xp", 50)
                val streak = obj.optInt("streakDays", 1)
                val isBlocked = obj.optBoolean("isBlocked", false)
                return@withContext UserEntity(
                    username = username,
                    password = pass,
                    xp = xp,
                    streakDays = streak,
                    isBlocked = isBlocked
                )
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Error getting user: ${e.message}")
        }
        null
    }

    suspend fun getUserOpenedPaths(username: String): List<String> = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$baseUrl/users/$username/opened.json")
                .get()
                .build()
            val response = client.newCall(request).execute()
            val body = response.body?.string()
            if (response.isSuccessful && !body.isNullOrEmpty() && body != "null") {
                val obj = JSONObject(body)
                val list = mutableListOf<String>()
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    if (obj.optBoolean(key, false)) {
                        list.add(key)
                    }
                }
                return@withContext list
            }
        } catch (e: Exception) {
            Log.e("FirebaseService", "Error getting opened paths: ${e.message}")
        }
        emptyList()
    }

    suspend fun registerUser(username: String, pass: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("pass", pass)
                put("xp", 50)
                put("streakDays", 1)
                put("createdAt", System.currentTimeMillis())
            }
            val request = Request.Builder()
                .url("$baseUrl/users/$username.json")
                .put(payload.toString().toRequestBody(jsonMediaType))
                .build()
            val response = client.newCall(request).execute()
            return@withContext response.isSuccessful
        } catch (e: Exception) {
            Log.e("FirebaseService", "Error registering user: ${e.message}")
            false
        }
    }

    suspend fun saveCourse(courseId: String, name: String, prefix: String, suffix: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("name", name)
                put("prefix", prefix)
                put("suffix", suffix)
                put("createdAt", System.currentTimeMillis())
            }
            val request = Request.Builder()
                .url("$baseUrl/paths/$courseId.json")
                .put(payload.toString().toRequestBody(jsonMediaType))
                .build()
            val response = client.newCall(request).execute()
            return@withContext response.isSuccessful
        } catch (e: Exception) {
            Log.e("FirebaseService", "Error saving course: ${e.message}")
            false
        }
    }

    suspend fun deleteCourse(courseId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$baseUrl/paths/$courseId.json")
                .delete()
                .build()
            val response = client.newCall(request).execute()
            return@withContext response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    suspend fun addSection(courseId: String, sectionId: String, name: String, link: String, tag: String, type: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("name", name)
                put("link", link)
                put("tag", tag)
                put("type", type)
                put("createdAt", System.currentTimeMillis())
            }
            val request = Request.Builder()
                .url("$baseUrl/paths/$courseId/sections/$sectionId.json")
                .put(payload.toString().toRequestBody(jsonMediaType))
                .build()
            val response = client.newCall(request).execute()
            return@withContext response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    suspend fun deleteSection(courseId: String, sectionId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url("$baseUrl/paths/$courseId/sections/$sectionId.json")
                .delete()
                .build()
            val response = client.newCall(request).execute()
            return@withContext response.isSuccessful
        } catch (e: Exception) {
            false
        }
    }

    suspend fun batchSaveCodes(courseId: String, codes: List<String>, owner: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject()
            val now = System.currentTimeMillis()
            for (code in codes) {
                val codeObj = JSONObject().apply {
                    put("used", false)
                    put("createdAt", now)
                    put("owner", owner)
                }
                root.put(code, codeObj)
            }
            val request = Request.Builder()
                .url("$baseUrl/generatedCodes/$courseId.json")
                .patch(root.toString().toRequestBody(jsonMediaType))
                .build()
            val response = client.newCall(request).execute()
            return@withContext response.isSuccessful
        } catch (e: Exception) {
            Log.e("FirebaseService", "Error batch saving codes: ${e.message}")
            false
        }
    }

    suspend fun findAndRedeemCode(code: String, username: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        try {
            val paths = fetchPaths()
            var matchedCourseId: String? = null
            var matchedCourseName: String? = null
            var codeNode: JSONObject? = null

            for ((pathId, course) in paths) {
                val request = Request.Builder()
                    .url("$baseUrl/generatedCodes/$pathId/$code.json")
                    .get()
                    .build()
                val response = client.newCall(request).execute()
                val body = response.body?.string()
                if (response.isSuccessful && !body.isNullOrEmpty() && body != "null") {
                    matchedCourseId = pathId
                    matchedCourseName = course.name
                    codeNode = JSONObject(body)
                    break
                }
            }

            if (matchedCourseId == null || codeNode == null) {
                return@withContext Pair(false, "❌ الكود غير صالح أو غير موجود")
            }

            val isUsed = codeNode.optBoolean("used", false)
            if (isUsed) {
                return@withContext Pair(false, "❌ الكود تم استخدامه من قبل")
            }

            val patchCode = JSONObject().apply {
                put("used", true)
                put("usedBy", username)
                put("usedAt", System.currentTimeMillis())
            }
            val markUsedReq = Request.Builder()
                .url("$baseUrl/generatedCodes/$matchedCourseId/$code.json")
                .patch(patchCode.toString().toRequestBody(jsonMediaType))
                .build()
            client.newCall(markUsedReq).execute()

            val openPayload = JSONObject().apply {
                put(matchedCourseId, true)
            }
            val openReq = Request.Builder()
                .url("$baseUrl/users/$username/opened.json")
                .patch(openPayload.toString().toRequestBody(jsonMediaType))
                .build()
            client.newCall(openReq).execute()

            return@withContext Pair(true, matchedCourseName ?: "الكورس")
        } catch (e: Exception) {
            Log.e("FirebaseService", "Error redeeming code: ${e.message}")
            return@withContext Pair(false, "❌ حدث خطأ في الاتصال بالسيرفر")
        }
    }
}
