package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CourseDao {
    @Query("SELECT * FROM courses ORDER BY createdAt DESC")
    fun getAllCourses(): Flow<List<CourseEntity>>

    @Query("SELECT * FROM courses WHERE id = :id LIMIT 1")
    suspend fun getCourseById(id: String): CourseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourse(course: CourseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCourses(courses: List<CourseEntity>)

    @Query("DELETE FROM courses WHERE id = :id")
    suspend fun deleteCourseById(id: String)

    @Query("DELETE FROM courses")
    suspend fun clearAll()
}

@Dao
interface SectionDao {
    @Query("SELECT * FROM sections WHERE courseId = :courseId ORDER BY orderIndex ASC, createdAt ASC")
    fun getSectionsForCourse(courseId: String): Flow<List<SectionEntity>>

    @Query("SELECT * FROM sections ORDER BY createdAt DESC")
    fun getAllSections(): Flow<List<SectionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSection(section: SectionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSections(sections: List<SectionEntity>)

    @Query("DELETE FROM sections WHERE id = :id")
    suspend fun deleteSectionById(id: String)

    @Query("DELETE FROM sections WHERE courseId = :courseId")
    suspend fun deleteSectionsForCourse(courseId: String)
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Query("UPDATE users SET xp = xp + :addXp WHERE username = :username")
    suspend fun addXp(username: String, addXp: Int)

    @Query("UPDATE users SET isBlocked = :blocked WHERE username = :username")
    suspend fun setBlockedStatus(username: String, blocked: Boolean)

    @Query("DELETE FROM users WHERE username = :username")
    suspend fun deleteUser(username: String)
}

@Dao
interface AccessDao {
    @Query("SELECT courseId FROM user_courses WHERE username = :username")
    fun getUnlockedCourseIds(username: String): Flow<List<String>>

    @Query("SELECT * FROM courses WHERE id IN (SELECT courseId FROM user_courses WHERE username = :username)")
    fun getUnlockedCourses(username: String): Flow<List<CourseEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM user_courses WHERE username = :username AND courseId = :courseId)")
    suspend fun hasAccess(username: String, courseId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun grantAccess(access: UserCourseAccess)

    @Query("DELETE FROM user_courses WHERE username = :username AND courseId = :courseId")
    suspend fun revokeAccess(username: String, courseId: String)
}

@Dao
interface ProgressDao {
    @Query("SELECT * FROM lesson_progress WHERE username = :username AND courseId = :courseId")
    fun getProgressForCourse(username: String, courseId: String): Flow<List<LessonProgress>>

    @Query("SELECT * FROM lesson_progress WHERE username = :username ORDER BY lastWatchedAt DESC LIMIT 1")
    fun getLastWatchedLesson(username: String): Flow<LessonProgress?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProgress(progress: LessonProgress)

    @Query("SELECT COUNT(*) FROM lesson_progress WHERE username = :username AND isCompleted = 1")
    fun getTotalCompletedLessonsCount(username: String): Flow<Int>
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM user_favorites WHERE username = :username ORDER BY addedAt DESC")
    fun getFavorites(username: String): Flow<List<UserFavorite>>

    @Query("SELECT EXISTS(SELECT 1 FROM user_favorites WHERE username = :username AND itemId = :itemId)")
    suspend fun isFavorite(username: String, itemId: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFavorite(fav: UserFavorite)

    @Query("DELETE FROM user_favorites WHERE username = :username AND itemId = :itemId")
    suspend fun removeFavorite(username: String, itemId: String)
}

@Dao
interface CodeDao {
    @Query("SELECT * FROM activation_codes WHERE courseId = :courseId")
    fun getCodesForCourse(courseId: String): Flow<List<ActivationCodeEntity>>

    @Query("SELECT * FROM activation_codes ORDER BY createdAt DESC")
    fun getAllCodes(): Flow<List<ActivationCodeEntity>>

    @Query("SELECT * FROM activation_codes WHERE code = :code LIMIT 1")
    suspend fun getCode(code: String): ActivationCodeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCode(code: ActivationCodeEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCodes(codes: List<ActivationCodeEntity>)

    @Query("UPDATE activation_codes SET used = 1, usedBy = :username, usedAt = :usedAt WHERE code = :code")
    suspend fun markCodeAsUsed(code: String, username: String, usedAt: Long = System.currentTimeMillis())
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAuditLogs(): Flow<List<AuditLog>>

    @Insert
    suspend fun insertLog(log: AuditLog)
}

@Database(
    entities = [
        CourseEntity::class,
        SectionEntity::class,
        ActivationCodeEntity::class,
        UserEntity::class,
        UserCourseAccess::class,
        LessonProgress::class,
        UserFavorite::class,
        AuditLog::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun courseDao(): CourseDao
    abstract fun sectionDao(): SectionDao
    abstract fun userDao(): UserDao
    abstract fun accessDao(): AccessDao
    abstract fun progressDao(): ProgressDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun codeDao(): CodeDao
    abstract fun auditDao(): AuditDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: android.content.Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "elsaad_edu_database.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
