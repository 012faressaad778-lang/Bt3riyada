package com.example.data.model

enum class DownloadFileType {
    APK,
    PDF
}

enum class DownloadStatus {
    IDLE,
    CONNECTING,
    DOWNLOADING,
    COMPLETED,
    FAILED,
    PAUSED
}

data class DownloadItem(
    val id: String,
    val title: String,
    val description: String,
    val fileType: DownloadFileType,
    val category: String, // e.g., "تطبيقات المنصة", "مذكرات وملازم", "نماذج امتحانات"
    val courseName: String = "عام لكل الطلاب",
    val fileSizeText: String, // e.g. "18.5 MB"
    val totalBytes: Long = 0L,
    val version: String = "v1.0",
    val downloadUrl: String,
    val cdnMirrorUrl: String? = null,
    val fileName: String,
    val localFilePath: String? = null,
    val progress: Int = 0,
    val downloadedBytes: Long = 0L,
    val status: DownloadStatus = DownloadStatus.IDLE,
    val errorMessage: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)
