package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.AppRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class MainUiState(
    val currentRoute: String = "auth", // "auth", "student", "course_detail", "admin", "favorites", "achievements"
    val currentUser: String? = null,
    val userRole: String = "none",
    val isDarkMode: Boolean = false,
    val currentThemeId: String = "default",
    val langMain: String = "ar",
    val langStyle: String = "amiyya",
    val selectedCourseId: String? = null,
    val selectedCourseName: String = "",
    val activePlayingVideo: Pair<String, String>? = null, // Pair(title, url)
    val activeViewingPdf: Pair<String, String>? = null, // Pair(title, url)
    val searchQuery: String = "",
    val toastMessage: String? = null,
    val celebrationData: Triple<String, String, String>? = null, // Triple(title, message, icon)
    val isSettingsOpen: Boolean = false,
    val isCertificateOpen: Boolean = false,
    val isLoading: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    val repository = AppRepository(application)

    private val _uiState = MutableStateFlow(
        MainUiState(
            currentUser = repository.getSavedUser(),
            userRole = repository.getSavedRole(),
            currentRoute = if (repository.getSavedRole() == "admin") "admin" else if (repository.getSavedUser() != null) "student" else "auth",
            isDarkMode = repository.isDarkMode(),
            currentThemeId = repository.getTheme(),
            langMain = repository.getLangMain(),
            langStyle = repository.getLangStyle()
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    // Data streams
    val allCourses: StateFlow<List<CourseEntity>> = repository.allCourses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAuditLogs: StateFlow<List<AuditLog>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<UserEntity>> = repository.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCodes: StateFlow<List<ActivationCodeEntity>> = repository.getAllCodes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadItems: StateFlow<List<DownloadItem>> = repository.downloadItems

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val unlockedCourses: StateFlow<List<CourseEntity>> = _uiState
        .flatMapLatest { state ->
            val username = state.currentUser ?: ""
            if (username.isNotBlank()) {
                repository.getUnlockedCourses(username)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val unlockedCourseIds: StateFlow<List<String>> = _uiState
        .flatMapLatest { state ->
            val username = state.currentUser ?: ""
            if (username.isNotBlank()) {
                repository.getUnlockedCourseIds(username)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val currentSections: StateFlow<List<SectionEntity>> = _uiState
        .flatMapLatest { state ->
            val cid = state.selectedCourseId
            if (cid != null) {
                repository.getSectionsForCourse(cid)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val userFavorites: StateFlow<List<UserFavorite>> = _uiState
        .flatMapLatest { state ->
            val username = state.currentUser ?: ""
            if (username.isNotBlank()) {
                repository.getFavorites(username)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val lastWatchedLesson: StateFlow<LessonProgress?> = _uiState
        .flatMapLatest { state ->
            val username = state.currentUser ?: ""
            if (username.isNotBlank()) {
                repository.getLastWatched(username)
            } else {
                flowOf(null)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        // Background silent sync on startup
        viewModelScope.launch {
            repository.syncPathsAndSections()
            val user = repository.getSavedUser()
            if (user != null) {
                repository.syncUserAccess(user)
            }
        }
    }

    fun login(username: String, pass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val (success, msg) = repository.login(username, pass)
            _uiState.update { it.copy(isLoading = false) }
            if (success) {
                _uiState.update {
                    it.copy(
                        currentUser = username,
                        userRole = msg,
                        currentRoute = if (msg == "admin") "admin" else "student",
                        celebrationData = Triple("✨ نورت المنصة", "أهلاً بك يا $username في منصة السعد التعليمية ⚡", "🎉")
                    )
                }
            }
            onResult(success, msg)
        }
    }

    fun register(username: String, pass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val (success, msg) = repository.register(username, pass)
            _uiState.update { it.copy(isLoading = false) }
            onResult(success, msg)
        }
    }

    fun logout() {
        repository.clearSession()
        _uiState.update {
            it.copy(
                currentUser = null,
                userRole = "none",
                currentRoute = "auth",
                selectedCourseId = null
            )
        }
        showToast("تم تسجيل الخروج بنجاح")
    }

    fun adminQuickLogin(pass: String, onResult: (Boolean) -> Unit) {
        if (pass.trim() == "Mohamed2090" || pass.trim() == "20092009") {
            repository.saveUserSession("MohamedX", "admin")
            _uiState.update {
                it.copy(
                    currentUser = "MohamedX",
                    userRole = "admin",
                    currentRoute = "admin"
                )
            }
            showToast("✅ أهلاً بك يا مدير!")
            onResult(true)
        } else {
            showToast("❌ كلمة سر المدير غير صحيحة")
            onResult(false)
        }
    }

    fun activateCode(code: String) {
        val user = _uiState.value.currentUser ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val (success, msg) = repository.activateCode(code, user)
            _uiState.update { it.copy(isLoading = false) }
            if (success) {
                _uiState.update {
                    it.copy(
                        celebrationData = Triple("🎉 مبروك يا وحش!", "تم تفعيل كورس «$msg» بنجاح في حسابك!", "🏆")
                    )
                }
            } else {
                showToast(msg)
            }
        }
    }

    fun openCourseDetail(courseId: String, courseName: String) {
        _uiState.update {
            it.copy(
                selectedCourseId = courseId,
                selectedCourseName = courseName,
                currentRoute = "course_detail"
            )
        }
    }

    fun navigateTo(route: String) {
        _uiState.update { it.copy(currentRoute = route) }
    }

    fun playVideo(title: String, url: String) {
        val user = _uiState.value.currentUser
        val cid = _uiState.value.selectedCourseId
        if (user != null && cid != null) {
            viewModelScope.launch {
                repository.updateLastWatched(user, cid, title)
            }
        }
        _uiState.update { it.copy(activePlayingVideo = Pair(title, url)) }
    }

    fun closeVideoPlayer() {
        _uiState.update { it.copy(activePlayingVideo = null) }
    }

    fun viewPdf(title: String, url: String) {
        val user = _uiState.value.currentUser
        val cid = _uiState.value.selectedCourseId
        if (user != null && cid != null) {
            viewModelScope.launch {
                repository.updateLastWatched(user, cid, title)
            }
        }
        _uiState.update { it.copy(activeViewingPdf = Pair(title, url)) }
    }

    fun closePdfViewer() {
        _uiState.update { it.copy(activeViewingPdf = null) }
    }

    fun toggleLessonCompleted(courseId: String, lessonId: String, completed: Boolean) {
        val user = _uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.toggleLessonCompleted(user, courseId, lessonId, completed)
            if (completed) {
                showToast("أحسنت! أضفنا 25 XP إلى رصيدك ⚡")
            }
        }
    }

    fun toggleFavorite(itemId: String, itemType: String, title: String, subtitle: String = "", link: String = "") {
        val user = _uiState.value.currentUser ?: return
        viewModelScope.launch {
            repository.toggleFavorite(user, itemId, itemType, title, subtitle, link)
            showToast("تم تحديث قائمة المفضلة ⭐")
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setTheme(themeId: String) {
        repository.saveTheme(themeId)
        _uiState.update { it.copy(currentThemeId = themeId) }
    }

    fun toggleDarkMode(isDark: Boolean) {
        repository.saveDarkMode(isDark)
        _uiState.update { it.copy(isDarkMode = isDark) }
    }

    fun setLangMain(main: String) {
        repository.saveLangMain(main)
        _uiState.update { it.copy(langMain = main) }
    }

    fun setLangStyle(style: String) {
        repository.saveLangStyle(style)
        _uiState.update { it.copy(langStyle = style) }
    }

    fun setSettingsOpen(isOpen: Boolean) {
        _uiState.update { it.copy(isSettingsOpen = isOpen) }
    }

    fun setCertificateOpen(isOpen: Boolean) {
        _uiState.update { it.copy(isCertificateOpen = isOpen) }
    }

    fun clearCelebration() {
        _uiState.update { it.copy(celebrationData = null) }
    }

    fun showToast(msg: String) {
        _uiState.update { it.copy(toastMessage = msg) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    // Admin operations
    fun createCourse(name: String, prefix: String, suffix: String) {
        viewModelScope.launch {
            val success = repository.createCourse(name, prefix, suffix)
            if (success) {
                showToast("✅ تم حفظ الكورس بنجاح")
            } else {
                showToast("❌ حدث خطأ أثناء الحفظ")
            }
        }
    }

    fun updateCourse(id: String, name: String, prefix: String, suffix: String) {
        viewModelScope.launch {
            val success = repository.updateCourse(id, name, prefix, suffix)
            if (success) {
                showToast("✅ تم تعديل الكورس بنجاح")
            }
        }
    }

    fun deleteCourse(id: String, name: String) {
        viewModelScope.launch {
            repository.deleteCourse(id, name)
            showToast("🗑️ تم حذف الكورس ومحتوياته")
        }
    }

    fun addSection(courseId: String, name: String, link: String, tag: String, type: String) {
        viewModelScope.launch {
            val success = repository.addSection(courseId, name, link, tag, type)
            if (success) {
                showToast("✅ تم إضافة المحتوى بنجاح")
            }
        }
    }

    fun deleteSection(courseId: String, sectionId: String, name: String) {
        viewModelScope.launch {
            repository.deleteSection(courseId, sectionId, name)
            showToast("🗑️ تم حذف المحتوى")
        }
    }

    fun generateCodes(courseId: String, count: Int, owner: String, onResult: (List<String>) -> Unit) {
        viewModelScope.launch {
            val codes = repository.generateAndSaveCodes(courseId, count, owner)
            onResult(codes)
        }
    }

    // Download Center actions
    fun startDownload(itemId: String) {
        repository.downloadManager.startDownload(itemId) { success, msg ->
            showToast(msg)
            if (success) {
                _uiState.value.currentUser?.let { user ->
                    viewModelScope.launch {
                        repository.logAudit(user, "تحميل ملف", itemId)
                    }
                }
            }
        }
    }

    fun cancelDownload(itemId: String) {
        repository.downloadManager.cancelDownload(itemId)
        showToast("تم إلغاء التنزيل")
    }

    fun openDownloadedFile(itemId: String) {
        repository.downloadManager.openDownloadedFile(itemId) { success, msg ->
            if (!success) {
                showToast(msg)
            }
        }
    }

    fun deleteDownloadedFile(itemId: String) {
        repository.downloadManager.deleteDownloadedFile(itemId)
        showToast("تم مسح الملف من وحدة التخزين")
    }

    fun syncDownloads() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.downloadManager.syncRemoteDownloadsCatalog()
            _uiState.update { it.copy(isLoading = false) }
            showToast("تم تحديث قائمة التنزيلات من الخادم 🔄")
        }
    }
}
