package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ProfileScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val unlockedCourses by viewModel.unlockedCourses.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val username = uiState.currentUser ?: "طالب السعد"
    val currentUserEntity = allUsers.find { it.username == username }
    val courseCount = unlockedCourses.size
    val xp = (currentUserEntity?.xp ?: 50) + (courseCount * 150)
    val streakDays = currentUserEntity?.streakDays ?: 1

    val levelText = when {
        courseCount >= 10 -> "👑 أسطورة المنصة"
        courseCount >= 5 -> "🏆 معلم كبير"
        courseCount >= 3 -> "⚡ شقيان ومجتهد"
        courseCount >= 1 -> "🌟 بدأ يتعلم"
        else -> "🌱 مبتدئ"
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Top Bar Header
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                shadowElevation = 4.dp,
                border = BorderStroke(1.dp, Color(0xFFF1F5F9))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.navigateTo("student") },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFFF8FAFC))
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "رجوع",
                                tint = Color(0xFF475569)
                            )
                        }

                        Text(
                            text = "الملف الشخصي",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF1E293B)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.setSettingsOpen(true) },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFF8FAFC))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "الإعدادات",
                            tint = Color(0xFF475569)
                        )
                    }
                }
            }
        }

        // 2. Profile User Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF4F46E5),
                                Color(0xFF4338CA)
                            )
                        )
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Avatar Circle
                    Surface(
                        shape = CircleShape,
                        color = Color.White,
                        shadowElevation = 6.dp,
                        modifier = Modifier.size(80.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = username.take(1).uppercase(),
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFF4F46E5)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = username,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.2f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = "🎓 طالب مسجل في منصة السعد",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // 3. Learning Stats Grid (4 Cards)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "إحصائيات التعلم والنشاط",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B),
                    modifier = Modifier.padding(horizontal = 4.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ProfileStatCard(
                        title = "الكورسات المفعلة",
                        value = "$courseCount كورس",
                        icon = Icons.Default.MenuBook,
                        iconColor = Color(0xFF059669),
                        bgColor = Color(0xFFECFDF5),
                        modifier = Modifier.weight(1f)
                    )
                    ProfileStatCard(
                        title = "نقاط الخبرة",
                        value = "$xp XP",
                        icon = Icons.Default.Bolt,
                        iconColor = Color(0xFFD97706),
                        bgColor = Color(0xFFFFFBEB),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    ProfileStatCard(
                        title = "المستوى الحالي",
                        value = levelText,
                        icon = Icons.Default.EmojiEvents,
                        iconColor = Color(0xFF4F46E5),
                        bgColor = Color(0xFFEEF2FF),
                        modifier = Modifier.weight(1f)
                    )
                    ProfileStatCard(
                        title = "أيام الاستمرار",
                        value = "$streakDays أيام متتالية",
                        icon = Icons.Default.Whatshot,
                        iconColor = Color(0xFFDC2626),
                        bgColor = Color(0xFFFEF2F2),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // 4. Quick Navigation List
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                shadowElevation = 2.dp
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    ProfileOptionItem(
                        title = "مركز التنزيلات والـ APK الرسمية",
                        subtitle = "تحميل تطبيقات المنصة ومذكرات الـ PDF للمذاكرة دون إنترنت",
                        icon = Icons.Default.CloudDownload,
                        iconTint = Color(0xFF059669),
                        iconBg = Color(0xFFECFDF5),
                        onClick = { viewModel.navigateTo("downloads") }
                    )

                    HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp), color = Color(0xFFF1F5F9))

                    ProfileOptionItem(
                        title = "شهاداتي وشهادة التقدير",
                        subtitle = "عرض وطباعة شهادة التفوق الخاصة بك",
                        icon = Icons.Default.WorkspacePremium,
                        iconTint = Color(0xFFD97706),
                        iconBg = Color(0xFFFFFBEB),
                        onClick = { viewModel.setCertificateOpen(true) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp), color = Color(0xFFF1F5F9))

                    ProfileOptionItem(
                        title = "المفضلة والمحاضرات المحفوظة",
                        subtitle = "الوصول السريع للدروس والكورسات المفضلة",
                        icon = Icons.Default.Star,
                        iconTint = Color(0xFF4F46E5),
                        iconBg = Color(0xFFEEF2FF),
                        onClick = { viewModel.navigateTo("favorites") }
                    )

                    HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp), color = Color(0xFFF1F5F9))

                    ProfileOptionItem(
                        title = "لوحة الإنجازات والجوائز",
                        subtitle = "متابعة تطور مستواك والأوسمة المكتسبة",
                        icon = Icons.Default.EmojiEvents,
                        iconTint = Color(0xFF059669),
                        iconBg = Color(0xFFECFDF5),
                        onClick = { viewModel.navigateTo("achievements") }
                    )

                    HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp), color = Color(0xFFF1F5F9))

                    ProfileOptionItem(
                        title = "جروب الدعم والواتساب",
                        subtitle = "التواصل المباشر مع مستر محمد السعد وزملائك",
                        icon = Icons.Default.Chat,
                        iconTint = Color(0xFF25D366),
                        iconBg = Color(0xFFDCFCE7),
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://chat.whatsapp.com/GqcDUSChHCwH7chD5aXkIo"))
                            context.startActivity(intent)
                        }
                    )

                    HorizontalDivider(modifier = Modifier.padding(horizontal = 12.dp), color = Color(0xFFF1F5F9))

                    ProfileOptionItem(
                        title = "إعدادات المظهر والسمات (29 سمة)",
                        subtitle = "تخصيص ألوان التطبيق والوضع الليلي",
                        icon = Icons.Default.Palette,
                        iconTint = Color(0xFF9333EA),
                        iconBg = Color(0xFFFAF5FF),
                        onClick = { viewModel.setSettingsOpen(true) }
                    )
                }
            }
        }

        // 5. Logout Action
        item {
            Surface(
                onClick = { viewModel.logout() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFFFEF2F2),
                border = BorderStroke(1.dp, Color(0xFFFECACA))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Logout,
                        contentDescription = "تسجيل خروج",
                        tint = Color(0xFFDC2626)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تسجيل الخروج من الحساب",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFDC2626)
                    )
                }
            }
        }
    }
}

@Composable
fun ProfileStatCard(
    title: String,
    value: String,
    icon: ImageVector,
    iconColor: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        shadowElevation = 1.dp,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = bgColor,
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1E293B),
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                color = Color(0xFF64748B),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun ProfileOptionItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = iconBg,
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }

            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
