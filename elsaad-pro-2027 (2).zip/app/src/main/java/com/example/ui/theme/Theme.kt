package com.example.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val LocalAppPalette = staticCompositionLocalOf {
    ThemePalettes.allThemes.first()
}

val LocalAppText = staticCompositionLocalOf {
    Translations.get("ar", "amiyya")
}

@Composable
fun ElsaadTheme(
    paletteId: String = "default",
    darkTheme: Boolean = false,
    langMain: String = "ar",
    langStyle: String = "amiyya",
    content: @Composable () -> Unit
) {
    val palette = ThemePalettes.getPalette(paletteId)
    val textSet = Translations.get(langMain, langStyle)

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = palette.primary,
            onPrimary = Color.Black,
            primaryContainer = palette.primary.copy(alpha = 0.2f),
            onPrimaryContainer = palette.primaryLight,
            secondary = palette.secondary,
            onSecondary = Color.Black,
            background = palette.darkBg,
            onBackground = palette.darkText,
            surface = palette.darkSurface,
            onSurface = palette.darkText,
            surfaceVariant = palette.darkSurface.copy(alpha = 0.8f),
            onSurfaceVariant = palette.darkTextSoft,
            outline = palette.primary.copy(alpha = 0.3f)
        )
    } else {
        lightColorScheme(
            primary = palette.primary,
            onPrimary = Color.White,
            primaryContainer = palette.primary.copy(alpha = 0.12f),
            onPrimaryContainer = palette.primary,
            secondary = palette.secondary,
            onSecondary = Color.White,
            background = palette.lightBg,
            onBackground = palette.lightText,
            surface = palette.lightSurface,
            onSurface = palette.lightText,
            surfaceVariant = palette.lightSurface.copy(alpha = 0.9f),
            onSurfaceVariant = palette.lightTextSoft,
            outline = palette.primary.copy(alpha = 0.2f)
        )
    }

    CompositionLocalProvider(
        LocalAppPalette provides palette,
        LocalAppText provides textSet
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
