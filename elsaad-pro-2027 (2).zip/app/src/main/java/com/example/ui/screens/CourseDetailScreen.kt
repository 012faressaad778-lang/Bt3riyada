package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.SectionEntity
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.LocalAppPalette
import com.example.ui.theme.LocalAppText

@Composable
fun CourseDetailScreen(viewModel: MainViewModel) {
    val palette = LocalAppPalette.current
    val text = LocalAppText.current

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val sections by viewModel.currentSections.collectAsStateWithLifecycle()
    val favorites by viewModel.userFavorites.collectAsStateWithLifecycle()

    val courseName = uiState.selectedCourseName.ifBlank { "محتوى الكورس" }
    var selectedTag by remember { mutableStateOf<String?>(null) }
    var sectionSearchQuery by remember { mutableStateOf("") }

    // Unique tags for filtering
    val availableTags = remember(sections) {
        listOf("الكل") + sections.map { it.tag }.filter { it.isNotBlank() }.distinct()
    }

    val filteredSections = remember(sections, selectedTag, sectionSearchQuery) {
        sections.filter { sec ->
            val tagMatch = selectedTag == null || selectedTag == "الكل" || sec.tag == selectedTag
            val searchMatch = sectionSearchQuery.isBlank() || sec.name.contains(sectionSearchQuery, ignoreCase = true)
            tagMatch && searchMatch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top App Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo("student") },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }

                    Text(
                        text = courseName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = {
                        val cid = uiState.selectedCourseId ?: ""
                        viewModel.toggleFavorite(cid, "course", courseName)
                    }
                ) {
                    val isFav = favorites.any { it.itemId == uiState.selectedCourseId }
                    Icon(
                        imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "مفضلة",
                        tint = if (isFav) Color(0xFFFBBF24) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Section Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp)
        ) {
            // Search inside course
            item {
                OutlinedTextField(
                    value = sectionSearchQuery,
                    onValueChange = { sectionSearchQuery = it },
                    placeholder = { Text("بحث في دروس هذا الكورس...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (sectionSearchQuery.isNotEmpty()) {
                            IconButton(onClick = { sectionSearchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = null)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp)
                )
            }

            // Tag Filter Chips
            if (availableTags.size > 1) {
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(availableTags) { tag ->
                            val isSelected = (selectedTag == null && tag == "الكل") || selectedTag == tag
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedTag = if (tag == "الكل") null else tag
                                },
                                label = {
                                    Text(
                                        text = tag,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                leadingIcon = {
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // Lessons List
            if (filteredSections.isEmpty()) {
                item {
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("📑", fontSize = 42.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = text.noContentYet,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            } else {
                items(filteredSections, key = { it.id }) { section ->
                    LessonItemCard(
                        section = section,
                        isFavorite = favorites.any { it.itemId == section.id },
                        onToggleFavorite = {
                            viewModel.toggleFavorite(
                                section.id,
                                "lesson",
                                section.name,
                                section.tag,
                                section.link
                            )
                        },
                        onPlayVideo = { viewModel.playVideo(section.name, section.link) },
                        onViewPdf = { viewModel.viewPdf(section.name, section.link) }
                    )
                }
            }

            // Back button
            item {
                Button(
                    onClick = { viewModel.navigateTo("student") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                ) {
                    Text(text.backToCourses, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LessonItemCard(
    section: SectionEntity,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onPlayVideo: () -> Unit,
    onViewPdf: () -> Unit
) {
    val palette = LocalAppPalette.current
    val isPdf = section.type == "pdf"
    val iconColor = if (isPdf) Color(0xFFEF4444) else Color(0xFFFF0000)

    GlassCard(
        modifier = Modifier.fillMaxWidth(),
        elevation = 3.dp,
        onClick = { if (isPdf) onViewPdf() else onPlayVideo() }
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Type Badge Icon
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = iconColor.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, iconColor.copy(alpha = 0.3f)),
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.PlayCircleFilled,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = section.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (section.tag.isNotBlank()) {
                        Surface(
                            shape = CircleShape,
                            color = palette.primary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "📁 ${section.tag}",
                                fontSize = 10.sp,
                                color = palette.primary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = if (isPdf) "ملف مذكرة PDF" else "درس فيديو يوتيوب",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Favorite Button & Play action
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
                        contentDescription = "مفضلة",
                        tint = if (isFavorite) Color(0xFFFBBF24) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }

                Surface(
                    shape = CircleShape,
                    color = palette.primary,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isPdf) Icons.Default.Visibility else Icons.Default.PlayArrow,
                            contentDescription = "فتح",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
