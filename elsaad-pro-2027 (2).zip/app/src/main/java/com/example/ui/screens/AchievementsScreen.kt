package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.LocalAppPalette
import com.example.ui.theme.LocalAppText

data class BadgeItem(
    val icon: String,
    val title: String,
    val description: String,
    val requiredCourses: Int,
    val xpReward: Int
)

@Composable
fun AchievementsScreen(viewModel: MainViewModel) {
    val palette = LocalAppPalette.current
    val text = LocalAppText.current
    val unlockedCourses by viewModel.unlockedCourses.collectAsStateWithLifecycle()
    val count = unlockedCourses.size

    val badges = listOf(
        BadgeItem("🌱", text.levelBeginner, "فتح أول خطوة والانضمام إلى منصة السعد", 0, 50),
        BadgeItem("🌟", text.levelLearner, "تفعيل كورس تعليمي واحد والبدء في المذاكرة", 1, 100),
        BadgeItem("⚡", text.levelHardworking, "تفعيل كورسين والاستمرار بجد ونشاط", 2, 250),
        BadgeItem("🏆", text.levelMaster, "تفعيل 3 كورسات والوصول لمرحلة التمكن والاحتراف", 3, 500),
        BadgeItem("👑", text.levelLegend, "تفعيل 5 كورسات أو أكثر واعتلاء قمة أساطير المنصة", 5, 1000)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // App Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo("student") },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = Color(0xFFFBBF24)
                    )
                    Text(
                        text = text.achievements,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp)
        ) {
            // Stats summary
            item {
                GlassCard(elevation = 6.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🔥", fontSize = 28.sp)
                            Text(
                                text = "$count",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = palette.primary
                            )
                            Text(
                                text = "كورسات نشطة",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(40.dp)
                                .background(MaterialTheme.colorScheme.outline)
                        )

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("⚡", fontSize = 28.sp)
                            Text(
                                text = "${count * 150 + 50} XP",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = palette.primary
                            )
                            Text(
                                text = "نقاط الخبرة",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Badges list
            items(badges) { badge ->
                val isUnlocked = count >= badge.requiredCourses

                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = if (isUnlocked) 4.dp else 1.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (isUnlocked) palette.primary.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f),
                            border = BorderStroke(
                                1.5.dp,
                                if (isUnlocked) palette.primary else Color.Gray.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier.size(56.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = badge.icon,
                                    fontSize = 28.sp
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = badge.title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = if (isUnlocked) MaterialTheme.colorScheme.onSurface else Color.Gray
                                )
                                if (isUnlocked) {
                                    Text("✓", color = Color(0xFF16A34A), fontWeight = FontWeight.Black)
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = badge.description,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "+${badge.xpReward} XP",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isUnlocked) palette.primary else Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}
