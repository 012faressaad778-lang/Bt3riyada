package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CourseEntity
import com.example.ui.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.LocalAppPalette
import com.example.ui.theme.LocalAppText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val palette = LocalAppPalette.current
    val text = LocalAppText.current

    val allCourses by viewModel.allCourses.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val allCodes by viewModel.allCodes.collectAsStateWithLifecycle()
    val allAuditLogs by viewModel.allAuditLogs.collectAsStateWithLifecycle()

    var selectedAdminTab by remember { mutableIntStateOf(0) } // 0: Courses, 1: Content, 2: Code Gen, 3: Logs

    // Course Form States
    var newCourseName by remember { mutableStateOf("") }
    var newCoursePrefix by remember { mutableStateOf("12") }
    var newCourseSuffix by remember { mutableStateOf("2027") }

    // Content Form States
    var selectedCourseForContent by remember { mutableStateOf<CourseEntity?>(null) }
    var contentTitle by remember { mutableStateOf("") }
    var contentLink by remember { mutableStateOf("") }
    var contentTag by remember { mutableStateOf("الوحدة الأولى") }
    var contentType by remember { mutableStateOf("video") } // "video" or "pdf"

    // Code Generator States
    var selectedCourseForCodes by remember { mutableStateOf<CourseEntity?>(null) }
    var codeCount by remember { mutableStateOf("10") }
    var codeOwner by remember { mutableStateOf("موزع عام") }
    var generatedCodesList by remember { mutableStateOf<List<String>>(emptyList()) }

    // Edit Course Dialog State
    var courseToEdit by remember { mutableStateOf<CourseEntity?>(null) }

    LaunchedEffect(allCourses) {
        if (selectedCourseForContent == null && allCourses.isNotEmpty()) {
            selectedCourseForContent = allCourses.first()
        }
        if (selectedCourseForCodes == null && allCourses.isNotEmpty()) {
            selectedCourseForCodes = allCourses.first()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("🛡️", fontSize = 20.sp)
                        Text(
                            text = text.adminPanelTitle,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.setCertificateOpen(true) }) {
                        Icon(Icons.Default.WorkspacePremium, contentDescription = "شهادة تقدير", tint = palette.primary)
                    }
                    IconButton(onClick = { viewModel.setSettingsOpen(true) }) {
                        Icon(Icons.Default.Settings, contentDescription = "الإعدادات")
                    }
                    IconButton(onClick = { viewModel.logout() }) {
                        Icon(Icons.Default.Logout, contentDescription = "خروج", tint = MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp)
        ) {
            // 1. Stats Overview
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AdminStatCard(
                        title = "الطلاب",
                        value = "${allUsers.size.coerceAtLeast(120)}",
                        icon = "👥",
                        modifier = Modifier.weight(1f)
                    )
                    AdminStatCard(
                        title = "الكورسات",
                        value = "${allCourses.size}",
                        icon = "📚",
                        modifier = Modifier.weight(1f)
                    )
                    AdminStatCard(
                        title = "الأكواد",
                        value = "${allCodes.size}",
                        icon = "📦",
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 2. Admin Navigation Tabs
            item {
                TabRow(
                    selectedTabIndex = selectedAdminTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = palette.primary
                ) {
                    Tab(
                        selected = selectedAdminTab == 0,
                        onClick = { selectedAdminTab = 0 },
                        text = { Text("📚 الكورسات", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedAdminTab == 1,
                        onClick = { selectedAdminTab = 1 },
                        text = { Text("📤 إضافة محتوى", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedAdminTab == 2,
                        onClick = { selectedAdminTab = 2 },
                        text = { Text("🎲 توليد أكواد", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedAdminTab == 3,
                        onClick = { selectedAdminTab = 3 },
                        text = { Text("📋 السجل", fontWeight = FontWeight.Bold) }
                    )
                }
            }

            // TAB 0: COURSES MANAGEMENT
            if (selectedAdminTab == 0) {
                // Add Course Form
                item {
                    GlassCard {
                        Text(
                            text = "➕ إضافة كورس جديد",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = newCourseName,
                            onValueChange = { newCourseName = it },
                            label = { Text(text.courseNameHint) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = newCoursePrefix,
                                onValueChange = { newCoursePrefix = it },
                                label = { Text(text.codePrefixHint) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                            OutlinedTextField(
                                value = newCourseSuffix,
                                onValueChange = { newCourseSuffix = it },
                                label = { Text(text.codeSuffixHint) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                if (newCourseName.isNotBlank()) {
                                    viewModel.createCourse(newCourseName, newCoursePrefix, newCourseSuffix)
                                    newCourseName = ""
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = CircleShape,
                            enabled = newCourseName.isNotBlank()
                        ) {
                            Text("💾 حفظ الكورس في السيرفر", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Existing Courses List
                item {
                    Text(
                        text = "قائمة الكورسات الحالية (${allCourses.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                items(allCourses, key = { it.id }) { course ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = course.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "الرمز: [${course.prefix}]XXXXXX[${course.suffix}]",
                                    fontSize = 11.sp,
                                    color = palette.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                IconButton(
                                    onClick = { courseToEdit = course }
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = palette.primary)
                                }
                                IconButton(
                                    onClick = { viewModel.deleteCourse(course.id, course.name) }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }

            // TAB 1: ADD CONTENT (VIDEO / PDF)
            if (selectedAdminTab == 1) {
                item {
                    GlassCard {
                        Text(
                            text = "📤 إضافة درس أو ملزمة إلى كورس",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Select Course
                        Text("اختر الكورس المستهدف:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            allCourses.forEach { c ->
                                val isSelected = selectedCourseForContent?.id == c.id
                                Surface(
                                    onClick = { selectedCourseForContent = c },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) palette.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, if (isSelected) palette.primary else Color.Transparent),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        RadioButton(selected = isSelected, onClick = { selectedCourseForContent = c })
                                        Text(c.name, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Type toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = contentType == "video",
                                onClick = { contentType = "video" },
                                label = { Text(text.videoType) },
                                modifier = Modifier.weight(1f)
                            )
                            FilterChip(
                                selected = contentType == "pdf",
                                onClick = { contentType = "pdf" },
                                label = { Text(text.pdfType) },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = contentTag,
                            onValueChange = { contentTag = it },
                            label = { Text(text.contentTagHint) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = contentTitle,
                            onValueChange = { contentTitle = it },
                            label = { Text(text.contentTitleHint) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = contentLink,
                            onValueChange = { contentLink = it },
                            label = { Text(text.contentLinkHint) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val cid = selectedCourseForContent?.id
                                if (cid != null && contentTitle.isNotBlank() && contentLink.isNotBlank()) {
                                    viewModel.addSection(cid, contentTitle, contentLink, contentTag, contentType)
                                    contentTitle = ""
                                    contentLink = ""
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = CircleShape,
                            enabled = selectedCourseForContent != null && contentTitle.isNotBlank() && contentLink.isNotBlank()
                        ) {
                            Text("➕ حفظ ونشر المحتوى", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // TAB 2: CODE GENERATOR
            if (selectedAdminTab == 2) {
                item {
                    GlassCard {
                        Text(
                            text = "📦 مولد أكواد التفعيل العشوائية (10 أرقام)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Select Course
                        Text("اختر كورس التفعيل:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            allCourses.forEach { c ->
                                val isSelected = selectedCourseForCodes?.id == c.id
                                Surface(
                                    onClick = { selectedCourseForCodes = c },
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) palette.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(1.dp, if (isSelected) palette.primary else Color.Transparent),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        RadioButton(selected = isSelected, onClick = { selectedCourseForCodes = c })
                                        Text(c.name)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = codeCount,
                                onValueChange = { codeCount = it },
                                label = { Text(text.codeCountHint) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                            OutlinedTextField(
                                value = codeOwner,
                                onValueChange = { codeOwner = it },
                                label = { Text(text.ownerHint) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                val cid = selectedCourseForCodes?.id
                                val count = codeCount.toIntOrNull() ?: 10
                                if (cid != null) {
                                    viewModel.generateCodes(cid, count, codeOwner) { codes ->
                                        generatedCodesList = codes
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = CircleShape,
                            enabled = selectedCourseForCodes != null
                        ) {
                            Text(text.generatePdfCodes, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (generatedCodesList.isNotEmpty()) {
                    item {
                        GlassCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "الأكواد المولدة حديثاً (${generatedCodesList.size})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Codes", generatedCodesList.joinToString("\n"))
                                            clipboard.setPrimaryClip(clip)
                                            viewModel.showToast("تم نسخ جميع الأكواد إلى الحافظة 📋")
                                        }
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "نسخ الكل")
                                    }

                                    IconButton(
                                        onClick = {
                                            val sendIntent = Intent().apply {
                                                action = Intent.ACTION_SEND
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    "📦 أكواد منصة السعد التعليمية (${selectedCourseForCodes?.name}):\n\n" +
                                                            generatedCodesList.joinToString("\n")
                                                )
                                                type = "text/plain"
                                            }
                                            context.startActivity(Intent.createChooser(sendIntent, "مشاركة الأكواد"))
                                        }
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "مشاركة")
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            generatedCodesList.forEachIndexed { idx, code ->
                                Text(
                                    text = "${idx + 1}. $code",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = palette.primary,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            // TAB 3: AUDIT LOGS
            if (selectedAdminTab == 3) {
                item {
                    Text(
                        text = "سجل النشاط والأمان (${allAuditLogs.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                if (allAuditLogs.isEmpty()) {
                    item {
                        GlassCard {
                            Text(
                                text = "لا توجد سجلات بعد",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                } else {
                    items(allAuditLogs) { log ->
                        GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("📋", fontSize = 20.sp)
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${log.action}: ${log.target}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "المستخدم: ${log.adminUser}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Edit Course Dialog
        courseToEdit?.let { targetCourse ->
            var editName by remember(targetCourse.id) { mutableStateOf(targetCourse.name) }
            var editPrefix by remember(targetCourse.id) { mutableStateOf(targetCourse.prefix) }
            var editSuffix by remember(targetCourse.id) { mutableStateOf(targetCourse.suffix) }

            AlertDialog(
                onDismissRequest = { courseToEdit = null },
                title = { Text("تعديل الكورس") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("اسم الكورس") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = editPrefix,
                            onValueChange = { editPrefix = it },
                            label = { Text("بداية الكود") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = editSuffix,
                            onValueChange = { editSuffix = it },
                            label = { Text("نهاية الكود") },
                            singleLine = true
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.updateCourse(targetCourse.id, editName, editPrefix, editSuffix)
                            courseToEdit = null
                        }
                    ) {
                        Text("حفظ التعديل")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { courseToEdit = null }) {
                        Text("إلغاء")
                    }
                }
            )
        }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    icon: String,
    modifier: Modifier = Modifier
) {
    val palette = LocalAppPalette.current
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, palette.primary.copy(alpha = 0.2f)),
        tonalElevation = 3.dp,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = icon, fontSize = 24.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                color = palette.primary
            )
            Text(
                text = title,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
