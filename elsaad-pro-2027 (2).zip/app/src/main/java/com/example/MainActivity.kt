package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.ElsaadTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val snackbarHostState = remember { SnackbarHostState() }

            // Handle toasts
            LaunchedEffect(uiState.toastMessage) {
                uiState.toastMessage?.let { msg ->
                    Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                    viewModel.clearToast()
                }
            }

            ElsaadTheme(
                paletteId = uiState.currentThemeId,
                darkTheme = uiState.isDarkMode,
                langMain = uiState.langMain,
                langStyle = uiState.langStyle
            ) {
                Scaffold(
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    bottomBar = {
                        if (uiState.currentRoute != "auth" && uiState.currentUser != null) {
                            AppBottomNavigation(
                                currentRoute = uiState.currentRoute,
                                isAdmin = uiState.userRole == "admin",
                                onNavigate = { viewModel.navigateTo(it) },
                                onOpenSettings = { viewModel.setSettingsOpen(true) }
                            )
                        }
                    },
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // Main Navigation Screen Switching
                        when (uiState.currentRoute) {
                            "auth" -> AuthScreen(viewModel = viewModel)
                            "student" -> StudentDashboardScreen(viewModel = viewModel)
                            "course_detail" -> CourseDetailScreen(viewModel = viewModel)
                            "downloads" -> DownloadsScreen(viewModel = viewModel)
                            "admin" -> if (uiState.userRole == "admin") AdminDashboardScreen(viewModel = viewModel) else StudentDashboardScreen(viewModel = viewModel)
                            "favorites" -> FavoritesScreen(viewModel = viewModel)
                            "achievements" -> AchievementsScreen(viewModel = viewModel)
                            "profile" -> ProfileScreen(viewModel = viewModel)
                            else -> StudentDashboardScreen(viewModel = viewModel)
                        }

                        // Video Player Modal
                        if (uiState.activePlayingVideo != null) {
                            YouTubePlayerDialog(
                                title = uiState.activePlayingVideo!!.first,
                                videoUrl = uiState.activePlayingVideo!!.second,
                                onDismiss = { viewModel.closeVideoPlayer() }
                            )
                        }

                        // PDF Viewer Modal
                        if (uiState.activeViewingPdf != null) {
                            PdfViewerDialog(
                                title = uiState.activeViewingPdf!!.first,
                                pdfUrl = uiState.activeViewingPdf!!.second,
                                onDismiss = { viewModel.closePdfViewer() }
                            )
                        }

                        // Certificate Generator Modal
                        if (uiState.isCertificateOpen) {
                            CertificateDialog(
                                initialStudentName = uiState.currentUser ?: "",
                                initialCourseName = uiState.selectedCourseName,
                                onDismiss = { viewModel.setCertificateOpen(false) }
                            )
                        }

                        // Settings & 29-Theme Picker Modal
                        if (uiState.isSettingsOpen) {
                            SettingsDialog(
                                currentThemeId = uiState.currentThemeId,
                                isDarkMode = uiState.isDarkMode,
                                langMain = uiState.langMain,
                                langStyle = uiState.langStyle,
                                onThemeSelected = { viewModel.setTheme(it) },
                                onDarkModeToggled = { viewModel.toggleDarkMode(it) },
                                onLangMainSelected = { viewModel.setLangMain(it) },
                                onLangStyleSelected = { viewModel.setLangStyle(it) },
                                onDismiss = { viewModel.setSettingsOpen(false) }
                            )
                        }

                        // Gamification Celebration Popup
                        if (uiState.celebrationData != null) {
                            CelebrationDialog(
                                title = uiState.celebrationData!!.first,
                                message = uiState.celebrationData!!.second,
                                icon = uiState.celebrationData!!.third,
                                onDismiss = { viewModel.clearCelebration() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppBottomNavigation(
    currentRoute: String,
    isAdmin: Boolean,
    onNavigate: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        shadowElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                icon = Icons.Default.Home,
                label = "الرئيسية",
                isSelected = currentRoute == "student" || currentRoute == "course_detail",
                onClick = { onNavigate("student") }
            )
            BottomNavItem(
                icon = Icons.Default.CloudDownload,
                label = "التنزيلات",
                isSelected = currentRoute == "downloads",
                onClick = { onNavigate("downloads") }
            )
            BottomNavItem(
                icon = Icons.Default.Star,
                label = "المفضلة",
                isSelected = currentRoute == "favorites",
                onClick = { onNavigate("favorites") }
            )
            if (isAdmin) {
                BottomNavItem(
                    icon = Icons.Default.AdminPanelSettings,
                    label = "الإدارة",
                    isSelected = currentRoute == "admin",
                    onClick = { onNavigate("admin") }
                )
            } else {
                BottomNavItem(
                    icon = Icons.Default.AccountCircle,
                    label = "الملف الشخصي",
                    isSelected = currentRoute == "profile",
                    onClick = { onNavigate("profile") }
                )
            }
            BottomNavItem(
                icon = Icons.Default.Settings,
                label = "الإعدادات",
                isSelected = false,
                onClick = onOpenSettings
            )
        }
    }
}

@Composable
fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val activeColor = Color(0xFF4F46E5)
    val inactiveColor = Color(0xFF94A3B8)

    Column(
        modifier = Modifier
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = if (isSelected) Color(0xFFEEF2FF) else Color.Transparent,
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isSelected) activeColor else inactiveColor,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) activeColor else inactiveColor
        )
    }
}

